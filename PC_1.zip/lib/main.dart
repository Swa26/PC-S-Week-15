import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  static const String _title = 'Flutter Stateful Clicker Counter';
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: _title,
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: AppBar(
          title: Text('MyApp'),
        ),
        body: const MyHome(),
      ),
    );
  }
}

class MyHome extends StatefulWidget {
  const MyHome({
    super.key,
  });

  _MyHomeState createState() => _MyHomeState();
}

class _MyHomeState extends State<MyHome> {
  int totalque = 6;
  int trueque = 1;
  int wronque = 5;
  double total = 0;
  String congo = "Congratulations!You are Passed";
  String sorry = "Oops..You Failed";
  @override
  Widget build(BuildContext context) {
    total = (trueque / totalque * 100).roundToDouble();
    return SafeArea(
      child: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(20),
          ),
          Row(
            children: [
              Container(
                margin: EdgeInsets.all(20),
                height: 50.0,
                width: 50.0,
                color: Colors.blue,
              ),
              Text('Total Question: $totalque'),
            ],
          ),
          Row(
            children: [
              Container(
                margin: EdgeInsets.all(20),
                height: 50.0,
                width: 50.0,
                color: Colors.green,
              ),
              Text('True Question: $trueque'),
            ],
          ),
          Row(
            children: [
              Container(
                margin: EdgeInsets.all(20),
                height: 50.0,
                width: 50.0,
                color: Colors.red,
              ),
              Text('Wrong Question: $wronque'),
              if (total < 35)
                Container(
                  margin: EdgeInsets.fromLTRB(40.0, 0.0, 0.0, 0.0),
                  height: 100.0,
                  width: 100.0,
                  //color: Colors.greenAccent,
                  decoration: BoxDecoration(
                    color: Colors.redAccent,
                    shape: BoxShape.circle,
                  ),

                  child: Center(
                    child: Text(
                      '$total %',
                      style: TextStyle(fontSize: 30.0),
                    ),
                  ),
                )
              else
                Container(
                  margin: EdgeInsets.fromLTRB(40.0, 0.0, 0.0, 0.0),
                  height: 100.0,
                  width: 100.0,
                  //color: Colors.greenAccent,
                  decoration: BoxDecoration(
                    color: Colors.greenAccent,
                    shape: BoxShape.circle,
                  ),

                  child: Center(
                    child: Text(
                      '$total %',
                      style: TextStyle(fontSize: 30.0),
                    ),
                  ),
                ),
            ],
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Container(
                margin: EdgeInsets.fromLTRB(0.0, 30.0, 0.0, 0.0),
                child: Column(
                  children: [
                    if (total < 35)
                      Text(
                        sorry,
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 15.0),
                      )
                    else
                      Text(
                        congo,
                        style: TextStyle(
                            fontWeight: FontWeight.bold, fontSize: 15.0),
                      ),
                    if (total < 35)
                      Image.asset(
                        'assets/stamp.webp',
                        height: 150.0,
                        width: 200.0,
                      )
                    else
                      Image.asset(
                        'assets/14.jpg',
                        height: 150.0,
                        width: 200.0,
                      ),
                  ],
                ),
              )
            ],
          )
        ],
      ),
    );
  }
}
